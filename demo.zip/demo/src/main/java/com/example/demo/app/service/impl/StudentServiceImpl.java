package com.example.demo.app.service.impl;

import com.example.demo.app.entity.oracle.Student;
import com.example.demo.app.repository.oracle.StudentRepository;
import com.example.demo.app.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    StudentRepository studentRepository;

    public Student saveStudent(Student student) {
        try {
            this.studentRepository.save(student);
        } catch (Exception ex){
            System.out.println(ex);
            throw ex;
        }
        return student;
    }
}
