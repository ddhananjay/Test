package com.example.demo.app.service.impl;

import com.example.demo.app.entity.oracle.Student;
import com.example.demo.app.service.OracleService;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class OracleServiceImpl implements OracleService {

    private final NamedParameterJdbcTemplate template;

    public OracleServiceImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Transactional
    public Student updateStudent(Student student) {
        MapSqlParameterSource queryParameters = new MapSqlParameterSource();
        queryParameters.addValue("id", student.getSid());
        queryParameters.addValue("name", student.getName());
        String query = "UPDATE Test_Student SET name= :name WHERE sid= :id ";
        template.update(query, queryParameters);
        return  student;
    }

}
