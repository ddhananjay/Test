package com.example.demo.app.repository.oracle;

import com.example.demo.app.entity.oracle.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, String> {
}
