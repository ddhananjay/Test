package com.example.demo.app.service;

import com.example.demo.app.entity.oracle.Student;

public interface StudentService {

     Student saveStudent(Student student);
}
