package com.example.demo.app.service;

import com.example.demo.app.entity.oracle.Student;

public interface OracleService {

    Student updateStudent(Student student);

}
