package com.example.demo.app.entity.couchbase;

import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@Accessors(chain = true)
@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class TestDocument {
    @Id
    private String id;

    private String name;

}
