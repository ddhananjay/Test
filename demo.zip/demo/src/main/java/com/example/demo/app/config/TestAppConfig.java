package com.example.demo.app.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.client.RestTemplate;

import java.sql.SQLException;

@Configuration
@EnableJpaRepositories(basePackages = "com.example.demo.app.repository.oracle")
public class TestAppConfig {

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    //Note
    //application needs transaction manager to be provided, without transaction manager fails  Spring Boot 3.X onwards
    //whereas it works fine with Spring Boot 2.7

   /* @Bean
    @Qualifier("transactionManager")
    public PlatformTransactionManager transactionManager() throws SQLException {
        return new JpaTransactionManager();
    }*/
}
