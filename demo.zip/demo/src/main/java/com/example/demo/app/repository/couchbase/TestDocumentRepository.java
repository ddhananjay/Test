package com.example.demo.app.repository.couchbase;

import com.example.demo.app.entity.couchbase.TestDocument;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TestDocumentRepository extends CrudRepository<TestDocument, String> {
}
