package com.example.demo.app.config;

import com.couchbase.client.java.env.ClusterEnvironment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.data.couchbase.config.AbstractCouchbaseConfiguration;
import org.springframework.data.couchbase.repository.config.EnableReactiveCouchbaseRepositories;

import java.time.Duration;

@Configuration
@EnableReactiveCouchbaseRepositories(basePackages = "com.example.demo.app.repository.couchbase")
public class CouchbaseConfiguration extends AbstractCouchbaseConfiguration {

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer() {
        PropertySourcesPlaceholderConfigurer configurer= new PropertySourcesPlaceholderConfigurer();
        configurer.setLocalOverride(true);
        return configurer;
    }

    @Value("${couchbase.connectionString}")
    private String connectionString;

    @Value("${couchbase.user.name}")
    private String userName;

    @Value("${couchbase.user.password}")
    private String password;

    @Value("${couchbase.bucket.name}")
    private String bucketName;

    @Override
    public String getConnectionString() {
        return connectionString;
    }

    @Override
    public String getUserName() {
        return userName;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getBucketName() {
        return bucketName;
    }

    protected void configureEnvironment(final ClusterEnvironment.Builder builder) {
        builder.timeoutConfig().connectTimeout(Duration.ofMillis(20000));
    }

}
