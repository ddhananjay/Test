package com.example.demo.app.controller;

import com.example.demo.app.entity.oracle.Student;
import com.example.demo.app.service.OracleService;
import com.example.demo.app.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
public class AppController {

    @Autowired
    StudentService studentService;

    @Autowired
    OracleService oracleService;

    @PostMapping(path = "/students")
    public ResponseEntity<Student> saveStudent(@RequestBody Student student) {
        try {
            this.studentService.saveStudent(student);
        } catch (Exception ex){
            System.out.println(ex);
        }
        return ResponseEntity.ok().body(student);
    }


    @PostMapping(path = "/students/update")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student) {
        try {
            this.oracleService.updateStudent(student);
        } catch (Exception ex){
            System.out.println(ex);
        }
        return ResponseEntity.ok().body(student);
    }
}
